package com.example.macstudent.login;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBhelper extends SQLiteOpenHelper {

    public static final String DBname="ParkingDB";
    public static final String TBname_UserInfo="UserInfo";
    //public static final String TBname_ParkingInfo="ParkinhInfo";


    public DBhelper(Context context) {
        super(context, DBname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//called only once while creating db

        try
        {
            String CREATE_TABLE = "CREATE TABLE "+TBname_UserInfo+"(Name varchar(100), Phone vrchar(20), "+
            "Email varchar(50) PRIMARY KEY, Password varchar(20),"+
            "DOB varchar(20))";

            Log.v("DBhelper",CREATE_TABLE);

            db.execSQL(CREATE_TABLE);
        }
        catch(Exception e)
        {
            Log.e("DBhelper",e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//everytime we do changes this method will run
//we r deleting the table and creating it again
        //data will be saved bcos sqlite will reload the data into newer version
        try
        {
            db.execSQL("DROP TABLE IF EXISTS "+TBname_UserInfo);
            onCreate(db);
        }
        catch (Exception e)
        {
            Log.e("DBhelper",e.getMessage());
        }
    }
}
